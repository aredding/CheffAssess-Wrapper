name 'ChefAssess-Wrapper'
maintainer 'Anna Redding'
maintainer_email 'you@example.com'
license 'All Rights Reserved'
description 'Cookbook wrapper that includes recipes for Windows Patches and IIS'
long_description 'Installs/Configures Patches and IIS for Win2012r2'
version '0.1.0'
chef_version '>= 12.1' if respond_to?(:chef_version)

# The `issues_url` points to the location where issues for this cookbook are
# tracked.  A `View Issues` link will be displayed on this cookbook's page when
# uploaded to a Supermarket.
#
# issues_url 'https://github.com/aredding/ChefAssess-Wrapper/issues'

# The `source_url` points to the development repository for this cookbook.  A
# `View Source` link will be displayed on this cookbook's page when uploaded to
# a Supermarket.
#
# source_url 'https://github.com/<insert_org_here>/ChefAssess-Wrapper'

depends 'IIS', '>= 6.7.2'
depends 'wsus-client', '>= 1.2.1'