# ChefAssess-Wrapper

Includes the Windows patch and IIS cookbooks
Overrides for attributes to define new IIS hosting site

