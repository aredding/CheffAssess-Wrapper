#
# Author:: Anna Redding
# Cookbook:: ChefAssess-Wrapper for IIS and WSUS-Client 
# Recipe:: Provides customization of PATCH and IIS cookbook defaults
#

###
# Install latest Microsoft patches
# Instructions
#     - automatically install updates required by windows node
###

include wsus-client


###
# Installs and configures IIS
# Instructions:
#     - Install IIS
#     - Open firewall port 80
#     - Create a site 'icons' on port 80
#     - Host the following content:   https://github.com/colebemis/feather.git
#
###

include iis 


directory "#{node['iis']['docroot']}/sitedir" do
   action [:create]       
end

iis_site 'New Site Config' do
   protocol [:siteproto]                  
   port [:siteport]              
   path "#{node['iis']['docroot']}/sitedir"
   action [:add,:start] 
end



