#
#  Overrides to IIS and WSUS-CLIENT cookbooks for Chef Assessment
#


### 
# Overrides for wsus-client cookbook
###

default['wsus_client']['automatic_update_behavior']                = :install


###
# Overrides for IIS cookbook
###

node.default['iis']['docroot']['sitedir']    = "#{ENV['SYSTEMDRIVE']}\\inetpub\\wwwroot\\icons"
node.default['iis']['source']     = "https://github.com/colebemis/feather.git"
 
###
node.default['iis_site'][':siteproto']       = ":http"
node.default['iis_site'][':siteport']        = "80"


